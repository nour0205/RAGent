import { useMemo, useState } from 'react';
import { AnimatePresence, motion } from 'framer-motion';
import {
  Activity,
  BookOpen,
  ChevronRight,
  ArrowRight,
  GraduationCap,
  Layers3,
  ShieldCheck,
  Zap,
} from 'lucide-react';
import { Area, AreaChart, CartesianGrid, RadialBar, RadialBarChart, ResponsiveContainer, Tooltip, XAxis } from 'recharts';
import type { AskResponse } from '../types';
import { motionProps, readinessData, trendData } from '../lib/constants';
import { routeLabel } from '../lib/utils';
import { postJson } from '../lib/api';
import GlassCard from '../components/ui/GlassCard';
import StatCard from '../components/ui/StatCard';
import SectionHeading from '../components/ui/SectionHeading';
import FeatureChip from '../components/ui/FeatureChip';
import GradientButton from '../components/ui/GradientButton';
import StatusBanner from '../components/ui/StatusBanner';
import { Field, PremiumInput, PremiumTextarea, Toggle } from '../components/ui/FormControls';

export default function AskPage({ backendUrl }: { backendUrl: string }) {
  const [question, setQuestion] = useState('');
  const [owner, setOwner] = useState('');
  const [useBasic, setUseBasic] = useState(false);
  const [loading, setLoading] = useState(false);
  const [error, setError] = useState<string | null>(null);
  const [result, setResult] = useState<AskResponse | null>(null);

  const stats = useMemo(() => {
    const sourceCount = result?.sources?.length || 0;
    return [
      { title: 'Answer Confidence', value: result?.answer ? 'High' : '—', change: result?.route ? `Routed via ${routeLabel(result.route)}` : 'Awaiting question', icon: ShieldCheck, tone: 'from-cyan-500/15 via-blue-500/10 to-transparent' },
      { title: 'Sources Retrieved', value: String(sourceCount), change: sourceCount ? 'Grounding attached' : 'No sources yet', icon: Layers3, tone: 'from-violet-500/15 via-fuchsia-500/10 to-transparent' },
      { title: 'Study Signal', value: result?.study_hint ? 'Active' : 'Standby', change: result?.study_hint || 'Hints appear after routed response', icon: GraduationCap, tone: 'from-emerald-500/15 via-emerald-500/5 to-transparent' },
    ];
  }, [result]);

  async function handleAsk() {
    if (!question.trim()) {
      setError('Please enter a question.');
      return;
    }

    setLoading(true);
    setError(null);
    try {
      const payload: Record<string, unknown> = { question: question.trim() };
      if (owner.trim()) payload.owner = owner.trim();
      const endpoint = "/ask";
      const data = await postJson<AskResponse>(`${backendUrl}${endpoint}`, payload);
      setResult(data);
    } catch (err: any) {
      setError(err?.message || 'Request failed.');
    } finally {
      setLoading(false);
    }
  }

  return (
    <motion.div {...motionProps} className="px-4 py-8 sm:px-6 lg:px-8">
      <div className="mx-auto max-w-7xl space-y-6">
        <div className="grid gap-4 md:grid-cols-3">
          {stats.map((item) => <StatCard key={item.title} {...item} />)}
        </div>

        <div className="grid gap-6 xl:grid-cols-[1.05fr_0.95fr]">
          <GlassCard className="p-6 sm:p-7">
            <div className="mb-6 flex items-start justify-between gap-4">
              <SectionHeading
                eyebrow="Question Workspace"
                title="Ask your study memory"
                description="This screen preserves the Streamlit ask flow, including optional owner, routed/basic mode, answer rendering, route label, study hint, and sources."
              />
              <div className="hidden rounded-2xl border border-cyan-400/15 bg-sky-50 px-3 py-2 text-xs text-sky-700 sm:block">
                Endpoint connected
              </div>
            </div>

            <div className="space-y-5">
              <Field label="Question" hint="Natural language supported">
                <PremiumTextarea
                  rows={7}
                  value={question}
                  onChange={(e) => setQuestion(e.target.value)}
                  placeholder="Example: What should I review before an exam on supervised learning?"
                />
              </Field>

              <div className="grid gap-4 md:grid-cols-2">
                <Field label="Owner" hint="Optional user scope">
                  <PremiumInput value={owner} onChange={(e) => setOwner(e.target.value)} placeholder="nour" />
                </Field>
                <Field label="Mode" hint="Choose retrieval path">
                  <Toggle checked={useBasic} onChange={setUseBasic} label={useBasic ? 'Using basic /ask' : 'Using /ask_routed'} />
                </Field>
              </div>

              {error ? <StatusBanner tone="warning" title="Request issue" message={error} /> : null}

              <div className="flex flex-wrap gap-3">
                <GradientButton onClick={handleAsk} disabled={loading}>
                  {loading ? 'Thinking over your notes...' : 'Ask Recall'}
                  {!loading && <ArrowRight className="h-4 w-4" />}
                </GradientButton>
                <GradientButton variant="secondary" onClick={() => setQuestion('What is normalization in databases?')}>Load example</GradientButton>
              </div>
            </div>
          </GlassCard>

          <div className="space-y-6">
            <GlassCard className="p-6">
              <div className="mb-5 flex items-center justify-between">
                <div>
                  <p className="text-sm text-slate-500">Study Activity</p>
                  <p className="text-xl font-semibold tracking-tight">Weekly interaction trend</p>
                </div>
                <div className="rounded-2xl border border-slate-200 bg-white/85 px-3 py-2 text-xs text-slate-600">Learning Analytics</div>
              </div>
              <div className="h-64">
                <ResponsiveContainer width="100%" height="100%">
                  <AreaChart data={trendData}>
                    <defs>
                      <linearGradient id="trendFill" x1="0" y1="0" x2="0" y2="1">
                        <stop offset="0%" stopColor="rgba(34,211,238,0.55)" />
                        <stop offset="100%" stopColor="rgba(168,85,247,0.03)" />
                      </linearGradient>
                    </defs>
                    <CartesianGrid stroke="rgba(255,255,255,0.06)" vertical={false} />
                    <XAxis dataKey="name" stroke="rgba(148,163,184,0.7)" tickLine={false} axisLine={false} />
                    <Tooltip contentStyle={{ background: 'rgba(15,23,42,0.95)', border: '1px solid rgba(255,255,255,0.1)', borderRadius: 16, color: 'white' }} />
                    <Area type="monotone" dataKey="value" stroke="rgba(34,211,238,0.95)" fill="url(#trendFill)" strokeWidth={2.5} />
                  </AreaChart>
                </ResponsiveContainer>
              </div>
            </GlassCard>

            <GlassCard className="p-6">
              <div className="grid gap-4 lg:grid-cols-[0.9fr_1.1fr] lg:items-center">
                <div className="h-52">
                  <ResponsiveContainer width="100%" height="100%">
                    <RadialBarChart data={readinessData} innerRadius="72%" outerRadius="100%" startAngle={90} endAngle={-270}>
                      <defs>
                        <linearGradient id="readinessFill" x1="0" y1="0" x2="1" y2="1">
                          <stop offset="0%" stopColor="rgba(34,211,238,0.95)" />
                          <stop offset="100%" stopColor="rgba(168,85,247,0.95)" />
                        </linearGradient>
                      </defs>
                      <RadialBar cornerRadius={24} background dataKey="value" />
                      <text x="50%" y="50%" textAnchor="middle" dominantBaseline="middle" className="fill-white text-xl font-semibold">
                        78%
                      </text>
                    </RadialBarChart>
                  </ResponsiveContainer>
                </div>
                <div>
                  <p className="text-sm text-slate-500">Study signal</p>
                  <h4 className="mt-2 text-2xl font-semibold tracking-tight">Learning readiness</h4>
                  <p className="mt-3 text-sm leading-7 text-slate-600">
                    Use this space for future metrics like source count, route distribution, latency, answer quality, or evaluation summaries.
                  </p>
                  <div className="mt-5 flex flex-wrap gap-3">
                    <FeatureChip icon={Zap} label="Fast retrieval" tone="border-sky-200 bg-sky-50 text-sky-700" />
                    <FeatureChip icon={Activity} label="Grounded outputs" tone="border-violet-200 bg-violet-50 text-violet-700" />
                  </div>
                </div>
              </div>
            </GlassCard>
          </div>
        </div>

        <AnimatePresence mode="wait">
          <motion.div key={result ? 'result' : 'empty'} initial={{ opacity: 0, y: 12 }} animate={{ opacity: 1, y: 0 }} exit={{ opacity: 0, y: -12 }} transition={{ duration: 0.28 }}>
            {result ? (
              <div className="grid gap-6 xl:grid-cols-[1.1fr_0.9fr]">
                <GlassCard className="p-6 sm:p-7">
                  <div className="mb-5 flex items-center justify-between gap-4">
                    <SectionHeading eyebrow="Generated Response" title="Answer" description="A clean reading space for grounded answers from Recall." />
                    {result.route ? (
                      <div className="rounded-full border border-violet-200 bg-violet-50 px-3 py-2 text-xs text-violet-700">
                        {routeLabel(result.route)}
                      </div>
                    ) : null}
                  </div>

                  <div className="rounded-[28px] border border-slate-200 bg-slate-50/80 p-5 text-sm leading-7 text-slate-700">
                    {result.answer || 'No answer returned.'}
                  </div>

                  {result.study_hint ? (
                    <div className="mt-5 rounded-2xl border border-sky-200 bg-sky-50 p-4">
                      <p className="text-sm font-medium text-sky-800">Study Hint</p>
                      <p className="mt-2 text-sm leading-7 text-sky-800">{result.study_hint}</p>
                    </div>
                  ) : null}
                </GlassCard>

                <GlassCard className="p-6 sm:p-7">
                  <div className="mb-5 flex items-center justify-between">
                    <SectionHeading eyebrow="Grounding" title="Sources" description="Each supporting chunk is presented as a readable expandable source card." />
                    <div className="rounded-full border border-slate-200 bg-white/85 px-3 py-2 text-xs text-slate-600">
                      {result.sources?.length || 0} sources
                    </div>
                  </div>
                  <div className="space-y-4">
                    {result.sources?.length ? (
                      result.sources.map((source, index) => (
                        <details key={`${source.document_id}-${index}`} className="group overflow-hidden rounded-[26px] border border-slate-200 bg-white/70 open:bg-white/90">
                          <summary className="flex cursor-pointer list-none items-center justify-between gap-4 px-5 py-4">
                            <div>
                              <p className="text-sm font-medium text-slate-900">
                                Source {index + 1} — {source.document_id || 'unknown'}
                              </p>
                              <p className="mt-1 text-xs text-slate-500">
                                Chunk {String(source.chunk_index ?? 'unknown')} · {source.retrieval_type || 'unknown'}
                                {source.hybrid_score !== null && source.hybrid_score !== undefined ? ` · score ${source.hybrid_score}` : ''}
                              </p>
                            </div>
                            <ChevronRight className="h-4 w-4 text-slate-500 transition group-open:rotate-90" />
                          </summary>
                          <div className="border-t border-slate-200 px-5 py-4 text-sm leading-7 text-slate-600">
                            {source.text || 'No source text returned.'}
                          </div>
                        </details>
                      ))
                    ) : (
                      <div className="rounded-2xl border border-slate-200 bg-white/70 px-4 py-4 text-sm text-slate-500">
                        No sources returned.
                      </div>
                    )}
                  </div>
                </GlassCard>
              </div>
            ) : (
              <GlassCard className="p-8 text-center">
                <BookOpen className="mx-auto h-10 w-10 text-slate-500" />
                <h4 className="mt-4 text-xl font-semibold tracking-tight text-slate-900">Waiting for a study question</h4>
                <p className="mx-auto mt-3 max-w-2xl text-sm leading-7 text-slate-500">
                  Once you submit a question, this area will show the answer, routed study intent, study hint, and expandable source evidence.
                </p>
              </GlassCard>
            )}
          </motion.div>
        </AnimatePresence>
      </div>
    </motion.div>
  );
}
